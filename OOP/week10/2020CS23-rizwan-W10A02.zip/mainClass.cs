﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace saveData
{
    abstract class mainClass
    {
        public abstract void save_csv(string data);
        public abstract void save_js(string data);
    }
}
